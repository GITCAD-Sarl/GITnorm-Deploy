﻿using System.IO;
using System.Security.Cryptography;

namespace BIMnorm.Revit2023.App.Utilities
{
    /// <summary>
    /// Fournit une méthode pour supprimer un fichier de manière sécurisée,
    /// en l’écrasant avec des données aléatoires avant suppression définitive.
    /// </summary>
    public static class SecureFileEraser
    {
        /// <summary>
        /// Supprime un fichier en écrasant son contenu de manière irréversible.
        /// </summary>
        /// <param name="filePath">Chemin complet du fichier à supprimer.</param>
        public static void Erase(string filePath)
        {
            if (!File.Exists(filePath))
                return;

            byte[] buffer = new byte[1024];

            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            {
                using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Write))
                {
                    long fullChunks = fs.Length / buffer.Length;
                    for (int i = 0; i < fullChunks; i++)
                    {
                        rng.GetBytes(buffer);
                        fs.Write(buffer, 0, buffer.Length);
                    }

                    int remaining = (int)(fs.Length % buffer.Length);
                    if (remaining > 0)
                    {
                        rng.GetBytes(buffer, 0, remaining);
                        fs.Write(buffer, 0, remaining);
                    }
                }
            }

            File.Delete(filePath);
        }
    }
}
