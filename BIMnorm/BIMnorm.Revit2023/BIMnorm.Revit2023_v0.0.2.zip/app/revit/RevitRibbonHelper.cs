﻿using System;
using System.Diagnostics;
using System.Reflection;
using Autodesk.Revit.UI;
using Autodesk.Windows;
using RevitUI = Autodesk.Revit.UI;
using WindowsUI = Autodesk.Windows;

namespace BIMnorm.Revit2023.App.Revit
{
    /// <summary>
    /// Fournit des méthodes utilitaires pour créer et configurer des éléments dans le ruban Revit.
    /// </summary>
    public static class RevitRibbonHelper
    {
        /// <summary>
        /// Crée un panneau de ruban personnalisé dans l'onglet spécifié.
        /// </summary>
        /// <param name="application">Instance de l'application Revit.</param>
        /// <param name="tabName">Nom de l'onglet cible.</param>
        /// <param name="panelName">Nom du panneau à créer.</param>
        /// <returns>Une instance de RibbonPanel créée, ou null si échec.</returns>
        public static RevitUI.RibbonPanel CreateNewPanel(RevitUI.UIControlledApplication application, string tabName, string panelName)
        {
            try
            {
                return application.CreateRibbonPanel(tabName, panelName);
            }
            catch (Exception ex)
            {
                RevitUI.TaskDialog.Show("Erreur", ex.Message);
                Debug.Print(ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// Crée un bouton dans le ruban Revit avec prise en charge d’image et de tooltip étendu.
        /// </summary>
        /// <param name="ribbonPanel">Le panneau dans lequel le bouton sera ajouté.</param>
        /// <param name="commandClassName">Nom complet de la classe de commande.</param>
        /// <param name="buttonName">Identifiant interne du bouton.</param>
        /// <param name="buttonText">Texte affiché sur le bouton.</param>
        /// <param name="toolTip">Tooltip de base du bouton.</param>
        /// <param name="imgBitmap">Nom de la ressource pour l'image principale.</param>
        /// <param name="videoPath">Chemin (URL ou local) vers une vidéo pour le tooltip étendu (facultatif).</param>
        /// <param name="expandedImgBitmap">Nom de la ressource pour une image étendue (facultatif).</param>
        public static void CreatePushButtonWithToolTip(
            RevitUI.RibbonPanel ribbonPanel,
            string commandClassName,
            string buttonName,
            string buttonText,
            string toolTip = "",
            string imgBitmap = "",
            string videoPath = "",
            string expandedImgBitmap = ""
        )
        {
            if (ribbonPanel == null)
                return;

            try
            {
                string assemblyPath = Assembly.GetExecutingAssembly().Location;

                var buttonData = new PushButtonData(buttonName, buttonText, assemblyPath, commandClassName)
                {
                    ToolTip = toolTip,
                    LargeImage = RevitResourceLoader.LoadEmbeddedImage(imgBitmap)
                };

                RevitUI.PushButton pushButton = ribbonPanel.AddItem(buttonData) as RevitUI.PushButton;

                if (pushButton != null)
                {
                    WindowsUI.RibbonButton ribbonButton = GetRibbonButton(pushButton);

                    if (ribbonButton != null)
                    {
                        ribbonButton.ToolTip = new WindowsUI.RibbonToolTip
                        {
                            Title = toolTip,
                            ExpandedContent = "Informations supplémentaires",
                            ExpandedVideo = string.IsNullOrEmpty(videoPath) ? null : new Uri(videoPath),
                            ExpandedImage = string.IsNullOrEmpty(expandedImgBitmap) ? null : RevitResourceLoader.LoadEmbeddedImage(expandedImgBitmap)
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                RevitUI.TaskDialog.Show("Erreur", ex.Message);
                Debug.Print(ex.ToString());
            }
        }

        /// <summary>
        /// Récupère l'objet RibbonButton interne d’un PushButton via la réflexion.
        /// </summary>
        private static WindowsUI.RibbonButton GetRibbonButton(RevitUI.PushButton pushButton)
        {
            MethodInfo getRibbonItemMethod = pushButton.GetType().GetMethod(
                "getRibbonItem",
                BindingFlags.NonPublic | BindingFlags.Instance
            );

            return getRibbonItemMethod?.Invoke(pushButton, null) as WindowsUI.RibbonButton;
        }

        /// <summary>
        /// Supprime un onglet du ruban Revit si son nom correspond exactement.
        /// </summary>
        /// <param name="tabName">Nom de l’onglet à supprimer.</param>
        public static void RemoveRibbonTab(string tabName)
        {
            RibbonTab tabToRemove = null;

            foreach (RibbonTab tab in ComponentManager.Ribbon.Tabs)
            {
                if (tab.Title.Equals(tabName, System.StringComparison.OrdinalIgnoreCase))
                {
                    tabToRemove = tab;
                    break;
                }
            }

            if (tabToRemove != null)
            {
                ComponentManager.Ribbon.Tabs.Remove(tabToRemove);
            }
        }
    }
}
