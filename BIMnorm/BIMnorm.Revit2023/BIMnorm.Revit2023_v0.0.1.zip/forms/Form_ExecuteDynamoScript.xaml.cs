﻿using System.Windows;

namespace BIMnorm.Revit2023
{
    /// <summary>
    /// Logique d'interaction pour UserControl1.xaml
    /// </summary>
    public partial class ProgressWindow : Window
    {
        public ProgressWindow()
        {
            InitializeComponent();
        }

        // Appel pour fermer la fenêtre une fois le traitement terminé
        public void CloseWindow()
        {
            this.Dispatcher.Invoke(() => this.Close());
        }
    }
}
