﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using System.Windows.Interop;

namespace BIMnorm.Revit2023.Forms
{
    /// <summary>
    /// Fenêtre de demande de licence BIMnorm.
    /// </summary>
    public partial class Form_LicenseDialog : Window
    {
        private readonly string _formUrl;

        public Form_LicenseDialog(string guid, string formUrl)
        {
            InitializeComponent();

            _formUrl = formUrl;
            GuidTextBox.Text = guid;
            FormUrlBox.Text = formUrl;

            Clipboard.SetText(guid);
            EnableBlur();
        }

        private void OnRequestClicked(object sender, RoutedEventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = _formUrl,
                    UseShellExecute = true
                });
            }
            catch
            {
                MessageBox.Show("Impossible d'ouvrir le lien. Copiez-le manuellement si nécessaire.", "Erreur", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void OnCancelClicked(object sender, RoutedEventArgs e) => Close();

        private void OnCopyTextBoxContent(object sender, MouseButtonEventArgs e)
        {
            if (sender is TextBox tb && !string.IsNullOrWhiteSpace(tb.Text))
            {
                Clipboard.SetText(tb.Text);

                string originalText = tb.Text;
                Brush originalBorderBrush = tb.BorderBrush;
                Thickness originalBorderThickness = tb.BorderThickness;
                Brush originalForeground = tb.Foreground;
                bool wasReadOnly = tb.IsReadOnly;

                tb.IsReadOnly = false;
                tb.Text = "✔ Copié !";
                tb.Foreground = new SolidColorBrush(Colors.White);
                tb.BorderBrush = new SolidColorBrush(Color.FromRgb(76, 175, 80));
                tb.BorderThickness = new Thickness(2);

                var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };
                timer.Tick += (s, args) =>
                {
                    timer.Stop();
                    tb.Text = originalText;
                    tb.Foreground = originalForeground;
                    tb.BorderBrush = originalBorderBrush;
                    tb.BorderThickness = originalBorderThickness;
                    tb.IsReadOnly = wasReadOnly;
                };
                timer.Start();
            }
        }

        private void EnableBlur()
        {
            try
            {
                var windowHelper = new WindowInteropHelper(this);
                var accent = new AccentPolicy { AccentState = AccentState.ACCENT_ENABLE_BLURBEHIND };

                var size = Marshal.SizeOf(accent);
                var ptr = Marshal.AllocHGlobal(size);
                Marshal.StructureToPtr(accent, ptr, false);

                var data = new WindowCompositionAttributeData
                {
                    Attribute = WindowCompositionAttribute.WCA_ACCENT_POLICY,
                    SizeOfData = size,
                    Data = ptr
                };

                SetWindowCompositionAttribute(windowHelper.Handle, ref data);
                Marshal.FreeHGlobal(ptr);
            }
            catch
            {
                // Ignoré si non supporté
            }
        }

        #region Fluent Blur Interop

        private enum AccentState { ACCENT_DISABLED = 0, ACCENT_ENABLE_BLURBEHIND = 3 }

        [StructLayout(LayoutKind.Sequential)]
        private struct AccentPolicy
        {
            public AccentState AccentState;
            public int AccentFlags;
            public int GradientColor;
            public int AnimationId;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct WindowCompositionAttributeData
        {
            public WindowCompositionAttribute Attribute;
            public IntPtr Data;
            public int SizeOfData;
        }

        private enum WindowCompositionAttribute { WCA_ACCENT_POLICY = 19 }

        [DllImport("user32.dll")]
        private static extern int SetWindowCompositionAttribute(IntPtr hwnd, ref WindowCompositionAttributeData data);

        #endregion
    }
}
