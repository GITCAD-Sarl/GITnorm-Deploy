﻿using System;
using System.Linq;
using System.Management;
using System.Security.Cryptography;
using System.Text;

namespace BIMnorm.Revit2023.App.API
{
    /// <summary>
    /// Utilitaires API : génération de GUID stable, vérification de modules CSV.
    /// </summary>
    public static class ApiUtilities
    {
        /// <summary>
        /// Génère un GUID unique basé sur des identifiants matériels stables.
        /// </summary>
        public static Guid GenerateStableUserGuid()
        {
            string motherboardSerial = GetWmiValue("Win32_BaseBoard", "SerialNumber");
            string diskSerial = GetWmiValue("Win32_PhysicalMedia", "SerialNumber");
            string biosUuid = GetWmiValue("Win32_ComputerSystemProduct", "UUID");
            string motherboardModel = GetWmiValue("Win32_BaseBoard", "Product");
            string username = Environment.UserName ?? string.Empty;
            string machineName = Environment.MachineName ?? string.Empty;

            string raw = string.Join("|", new[]
            {
                Sanitize(motherboardSerial),
                Sanitize(diskSerial),
                Sanitize(biosUuid),
                Sanitize(motherboardModel),
                Sanitize(username),
                Sanitize(machineName)
            });

            using (SHA256 sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(raw));
                byte[] guidBytes = hash.Take(16).ToArray();
                return new Guid(guidBytes);
            }
        }

        private static string GetWmiValue(string wmiClass, string wmiProperty)
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher($"SELECT {wmiProperty} FROM {wmiClass}"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        object val = obj[wmiProperty];
                        if (val != null)
                        {
                            string s = val.ToString().Trim();
                            if (!string.IsNullOrWhiteSpace(s) && !s.Equals("To be filled by O.E.M.", StringComparison.OrdinalIgnoreCase))
                                return s;
                        }
                    }
                }
            }
            catch
            {
            }
            return string.Empty;
        }

        private static string Sanitize(string input)
        {
            return input?.Trim().Replace(" ", "_").Replace(";", "_") ?? string.Empty;
        }

        /// <summary>
        /// Vérifie si une valeur est contenue dans une chaîne CSV (insensible à la casse, nettoyée).
        /// </summary>
        public static bool ContainsValueInCsv(string csv, string valueToFind)
        {
            if (string.IsNullOrWhiteSpace(csv) || string.IsNullOrWhiteSpace(valueToFind))
                return false;

            string[] elements = csv.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            return elements.Any(e => string.Equals(e.Trim(), valueToFind.Trim(), StringComparison.OrdinalIgnoreCase));
        }
    }
}
