﻿using System;
using System.Windows;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;

namespace BIMnorm.Revit2023.App.API
{
    /// <summary>
    /// Gère la vérification de la licence utilisateur en interrogeant l'API distante.
    /// </summary>
    public static class ApiConnection
    {
        /// <summary>
        /// Vérifie l'API avec le GUID utilisateur et stocke les résultats (synchrone, compatible Revit).
        /// </summary>
        public static void CheckApiAndStoreResults()
        {
            GlobalVariables.Global_userGuid = ApiUtilities.GenerateStableUserGuid();
            if (GlobalVariables.Global_DebugMode)
            {
                Console.WriteLine("GUID utilisateur : " + GlobalVariables.Global_userGuid);
                Console.WriteLine("-------");
            }

            string url = GlobalVariables.API_Url + GlobalVariables.Global_userGuid;
            string jsonString = ApiHttpHelper.GetJsonStringFromApi(url);

            if (GlobalVariables.API_Status == "API REQUEST ERROR RETURN NULL")
            {
                MessageBox.Show(
                    "Serveur indisponible - Veuillez essayer plus tard",
                    GlobalVariables.Global_Software_Name + " " + GlobalVariables.Global_Software_Version + " : API Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );
                return;
            }

            JObject root = JObject.Parse(jsonString);
            GlobalVariables.API_Status = root["status"]?.ToString();

            JObject data = root["data"] as JObject;
            if (data != null)
            {
                JArray modulesArray = data["modules"] as JArray;
                if (modulesArray != null)
                {
                    List<string> modulesList = new List<string>();
                    foreach (JToken item in modulesArray)
                    {
                        modulesList.Add(item.ToString());
                    }
                    GlobalVariables.API_Modules = string.Join(",", modulesList);
                }

                GlobalVariables.API_Version = data["version"]?.ToString();
            }

            if (GlobalVariables.Global_DebugMode)
            {
                Console.WriteLine("Status: " + GlobalVariables.API_Status);
                Console.WriteLine("Modules: " + GlobalVariables.API_Modules);
                Console.WriteLine("Version: " + GlobalVariables.API_Version);
            }
        }
    }
}
