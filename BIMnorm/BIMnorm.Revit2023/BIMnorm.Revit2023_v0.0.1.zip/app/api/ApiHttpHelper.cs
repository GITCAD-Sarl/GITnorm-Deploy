﻿using System;
using System.Net.Http;

namespace BIMnorm.Revit2023.App.API
{
    /// <summary>
    /// Gère les appels HTTP vers l'API distante.
    /// </summary>
    public static class ApiHttpHelper
    {
        /// <summary>
        /// Envoie une requête HTTP GET et retourne la réponse en JSON.
        /// </summary>
        public static string GetJsonStringFromApi(string url)
        {
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    return client.GetStringAsync(url).GetAwaiter().GetResult();
                }
                catch
                {
                    GlobalVariables.API_Status = "API REQUEST ERROR RETURN NULL";
                    return "{}";
                }
            }
        }

        /// <summary>
        /// Envoie un log à l’API (non bloquant si DebugMode activé).
        /// </summary>
        public static void SendLogToServer(string message)
        {
            if (GlobalVariables.Global_DebugMode) return;

            string machine = Environment.MachineName;
            string user = Environment.UserName;
            string fullMessage = $"{machine} | {user} | {message}";
            string encodedMessage = Uri.EscapeDataString(fullMessage);
            string fullUrl = GlobalVariables.API_LogURL + encodedMessage;

            using (HttpClient client = new HttpClient())
            {
                try
                {
                    client.GetAsync(fullUrl).GetAwaiter().GetResult();
                }
                catch
                {
                    // Silencieux pour éviter tout blocage.
                }
            }
        }
    }
}
