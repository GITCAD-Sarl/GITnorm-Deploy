﻿using System;
using System.Windows;
using System.Windows.Interop;

namespace BIMnorm.Revit2023.App.API
{
    /// <summary>
    /// Gère la demande d'accès à une licence via un formulaire Microsoft Forms.
    /// </summary>
    public static class ApiRequestAccess
    {
        /// <summary>
        /// Ouvre une fenêtre avec lien vers le formulaire et copie le GUID utilisateur.
        /// </summary>
        public static void OpenMicrosoftFormsRequest()
        {
            Clipboard.SetText(GlobalVariables.Global_userGuid.ToString());

            var dialog = new BIMnorm.Revit2023.Forms.Form_LicenseDialog(
                GlobalVariables.Global_userGuid.ToString(),
                "https://forms.office.com/e/y41Jcxrtw6"
            );

            IntPtr revitHandle = Autodesk.Windows.ComponentManager.ApplicationWindow;
            new WindowInteropHelper(dialog) { Owner = revitHandle };
            dialog.ShowDialog();
        }
    }
}
