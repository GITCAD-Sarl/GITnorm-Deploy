﻿using System;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace BIMnorm.Revit2023
{
    public class Updater
    {
        private readonly string _connectionString;
        private readonly string _currentVersion;
        private readonly string _downloadUrl;
        private readonly string _setupFilePath;

        public Updater(string connectionString, string currentVersion, string downloadUrl, string setupFilePath)
        {
            _connectionString = connectionString;
            _currentVersion = currentVersion;
            _downloadUrl = downloadUrl;
            _setupFilePath = setupFilePath;
        }

        public async Task CheckAndUpdateAsync()
        {
            try
            {
                // Vérifier la version dans la base de données
                string latestVersion = await GetLatestVersionFromDatabaseAsync();

                if (IsNewVersionAvailable(latestVersion))
                {
                    Console.WriteLine("Nouvelle version détectée : téléchargement en cours...");
                    await DownloadInstallerAsync();
                    RunInstallerInBackground();
                }
                else
                {
                    Console.WriteLine("Version actuelle à jour.");

                    // Emplacement prévu pour actions futures si version inférieure ou égale
                    // Remarque : Ici, nous pourrions implémenter d'autres actions si besoin.
                }
            }
            catch (Exception ex)
            {
                // Gestion des erreurs : affiche l'erreur dans la console
                Console.WriteLine($"Erreur lors de la mise à jour : {ex.Message}");
            }
        }

        private async Task<string> GetLatestVersionFromDatabaseAsync()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    string query = "SELECT TOP 1 Version FROM Versions ORDER BY Date DESC";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        var result = await command.ExecuteScalarAsync();
                        return result?.ToString() ?? throw new InvalidOperationException("La version n'a pas pu être récupérée.");
                    }
                }
            }
            catch (SqlException ex)
            {
                // Gestion des erreurs SQL
                Console.WriteLine($"Erreur SQL : {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                // Gestion des autres erreurs
                Console.WriteLine($"Erreur lors de la récupération de la version : {ex.Message}");
                throw;
            }
        }

        private bool IsNewVersionAvailable(string latestVersion)
        {
            // Comparaison des versions, retourne vrai si la dernière version est supérieure
            return string.Compare(latestVersion, _currentVersion, StringComparison.Ordinal) > 0;
        }

        private async Task DownloadInstallerAsync()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    HttpResponseMessage response = await client.GetAsync(_downloadUrl);
                    response.EnsureSuccessStatusCode();

                    using (FileStream fileStream = new FileStream(_setupFilePath, FileMode.Create, FileAccess.Write, FileShare.None))
                    {
                        await response.Content.CopyToAsync(fileStream);
                    }

                    Console.WriteLine("Téléchargement de l'installateur terminé.");
                }
            }
            catch (HttpRequestException ex)
            {
                // Gestion des erreurs de téléchargement HTTP
                Console.WriteLine($"Erreur lors du téléchargement : {ex.Message}");
                throw;
            }
            catch (IOException ex)
            {
                // Gestion des erreurs d'écriture de fichier
                Console.WriteLine($"Erreur d'écriture de fichier : {ex.Message}");
                throw;
            }
        }

        private void RunInstallerInBackground()
        {
            try
            {
                Process installerProcess = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName = _setupFilePath,
                        Arguments = "/silent",  // L'argument "/silent" dépend de l'installateur utilisé
                        UseShellExecute = false,
                        CreateNoWindow = true
                    }
                };

                installerProcess.Start();
                Console.WriteLine("Installateur lancé en arrière-plan.");
            }
            catch (Exception ex)
            {
                // Gestion des erreurs de démarrage du processus
                Console.WriteLine($"Erreur lors de l'exécution de l'installateur : {ex.Message}");
                throw;
            }
        }
    }
}

