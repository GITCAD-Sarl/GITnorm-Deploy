﻿using Autodesk.Revit.UI;
using Dynamo.Applications;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Forms;
using BIMnorm.Revit2023.App.Utilities;

namespace BIMnorm.Revit2023.App.Revit
{
    /// <summary>
    /// Fournit des méthodes pour exécuter des scripts Dynamo chiffrés dans Revit.
    /// </summary>
    public static class RevitDynamoExecutor
    {
        /// <summary>
        /// Événement déclenché lorsque le script Dynamo a été entièrement exécuté.
        /// </summary>
        public static event Action ScriptExecutionCompleted;

        /// <summary>
        /// Déchiffre un script Dynamo chiffré (.dynamo), l'exécute dans Revit, puis le supprime de manière sécurisée.
        /// </summary>
        /// <param name="commandData">Données de commande Revit.</param>
        /// <param name="encryptedFilePath">Chemin du fichier .dynamo chiffré.</param>
        /// <returns>Le résultat de l'exécution du script.</returns>
        public static Result ExecuteEncryptedDynamoScript(ExternalCommandData commandData, string encryptedFilePath)
        {
            try
            {
                string tempDynFile = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString() + ".dyn");

                using (Aes aes = Aes.Create())
                {
                    aes.Key = EncryptionKeys.EncryptionKey;
                    aes.IV = EncryptionKeys.InitializationVector;

                    using (FileStream inputStream = new FileStream(encryptedFilePath, FileMode.Open, FileAccess.Read))
                    using (FileStream outputStream = new FileStream(tempDynFile, FileMode.Create, FileAccess.Write))
                    using (CryptoStream cryptoStream = new CryptoStream(inputStream, aes.CreateDecryptor(), CryptoStreamMode.Read))
                    {
                        cryptoStream.CopyTo(outputStream);
                    }
                }

                Result executionResult = ExecuteDynamoScript(commandData, tempDynFile);

                SecureFileEraser.Erase(tempDynFile);

                ScriptExecutionCompleted?.Invoke();
                return executionResult;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'exécution du script Dynamo : " + ex.Message);
                return Result.Failed;
            }
        }

        /// <summary>
        /// Exécute un fichier Dynamo (.dyn) dans Revit via l'API de Dynamo.
        /// </summary>
        /// <param name="commandData">Données de commande Revit.</param>
        /// <param name="dynamoFilePath">Chemin du fichier .dyn.</param>
        /// <returns>Le résultat de l'exécution.</returns>
        public static Result ExecuteDynamoScript(ExternalCommandData commandData, string dynamoFilePath)
        {
            try
            {
                var dynamoCommandData = new DynamoRevitCommandData
                {
                    Application = commandData.Application,
                    JournalData = new Dictionary<string, string>
                    {
                        { JournalKeys.ShowUiKey, false.ToString() },
                        { JournalKeys.AutomationModeKey, true.ToString() },
                        { JournalKeys.DynPathKey, dynamoFilePath },
                        { JournalKeys.DynPathExecuteKey, true.ToString() },
                        { JournalKeys.ForceManualRunKey, false.ToString() },
                        { JournalKeys.ModelShutDownKey, true.ToString() },
                        { JournalKeys.ModelNodesInfo, false.ToString() }
                    }
                };

                var dynamoRevit = new DynamoRevit();
                return dynamoRevit.ExecuteCommand(dynamoCommandData);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'exécution du fichier Dynamo : " + ex.Message);
                return Result.Failed;
            }
        }
    }
}
