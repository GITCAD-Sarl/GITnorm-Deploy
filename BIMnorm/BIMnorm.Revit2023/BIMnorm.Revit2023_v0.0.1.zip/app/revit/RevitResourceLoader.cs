﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace BIMnorm.Revit2023.App.Revit
{
    /// <summary>
    /// Fournit des méthodes pour charger des ressources embarquées dans l’assembly.
    /// </summary>
    public static class RevitResourceLoader
    {
        /// <summary>
        /// Charge une image intégrée à partir des ressources de l’assembly, via son nom.
        /// </summary>
        /// <param name="resourceName">Nom complet de la ressource (incluant le namespace et le dossier).</param>
        /// <returns>Image sous forme de ImageSource.</returns>
        public static ImageSource LoadEmbeddedImage(string resourceName)
        {
            var assembly = Assembly.GetExecutingAssembly();
            using (var stream = assembly.GetManifestResourceStream(resourceName))
            {
                if (stream == null)
                    throw new ArgumentException($"Ressource non trouvée : {resourceName}");

                var bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.StreamSource = stream;
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.EndInit();
                return bitmap;
            }
        }
    }
}
