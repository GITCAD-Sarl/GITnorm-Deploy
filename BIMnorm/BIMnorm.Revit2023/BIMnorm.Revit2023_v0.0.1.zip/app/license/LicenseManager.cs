﻿using Autodesk.Revit.UI;
using BIMnorm.Revit2023.App.API;
using BIMnorm.Revit2023.App.Revit;
using System;
using System.Windows;

namespace BIMnorm.Revit2023.App.License
{
    /// <summary>
    /// Fournit des fonctions de validation de licence avant exécution de commandes.
    /// </summary>
    public static class LicenseManager
    {
        /// <summary>
        /// Vérifie si le module demandé est autorisé par la licence.
        /// </summary>
        /// <param name="requestedModule">Nom du module requis (ex. "Gratuit", "Dynamo", etc.).</param>
        /// <returns>Result.Succeeded si autorisé, Result.Failed sinon.</returns>
        public static Result Validate(string requestedModule)
        {
            try
            {
                // Vérification temporelle
                bool shouldCheck =
                    GlobalVariables.API_LastCheckUtc == null ||
                    DateTime.UtcNow.Subtract(GlobalVariables.API_LastCheckUtc.Value).TotalHours >= GlobalVariables.API_CheckIntervalHours;

                if (shouldCheck)
                {
                    ApiConnection.CheckApiAndStoreResults();
                    GlobalVariables.API_LastCheckUtc = DateTime.UtcNow;
                }

                // Si l'API ne répond pas correctement -> supprimer le ruban
                if (!string.Equals(GlobalVariables.API_Status, "ok", StringComparison.OrdinalIgnoreCase))
                {
                    RevitRibbonHelper.RemoveRibbonTab("BIMnorm");
                    MessageBox.Show(
                        GlobalVariables.API_ConnectionErrorMessage,
                        GlobalVariables.API_ConnectionErrorTitle,
                        MessageBoxButton.OK,
                        MessageBoxImage.Error
                    );
                    return Result.Failed;
                }

                // Vérifie la présence du module
                if (!ApiUtilities.ContainsValueInCsv(GlobalVariables.API_Modules, requestedModule))
                {
                    MessageBox.Show(
                        $"Votre licence ne permet pas d'utiliser le module \"{requestedModule}\".",
                        "Accès refusé",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning
                    );
                    return Result.Failed;
                }

                return Result.Succeeded;
            }
            catch (Exception)
            {
                RevitRibbonHelper.RemoveRibbonTab("BIMnorm");
                MessageBox.Show(
                    GlobalVariables.API_ConnectionErrorMessage,
                    GlobalVariables.API_ConnectionErrorTitle,
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
                return Result.Failed;
            }
        }
    }
}
