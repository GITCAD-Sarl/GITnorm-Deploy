﻿using Autodesk.Revit.UI;
using System;
using System.IO;

namespace BIMnorm.Revit2023
{
    public static class GlobalVariables
    {
        // Globals
        public static Boolean Global_DebugMode = false; // Mode debug
        public static Guid Global_userGuid; // GUID généré à partir du hardware de l'utilisateur

        public static string Global_Software_Name = "BIMnorm";
        public static string Global_Software_Version = "2023";

        // API
        public static int API_CheckIntervalHours = 4;
        public static DateTime? API_LastCheckUtc = null;

        public static string API_ConnectionErrorTitle = "Vérification de la licence impossible";
        public static string API_ConnectionErrorMessage = "La connexion au serveur de licences a échoué. Veuillez vérifier votre connexion internet ou réessayer plus tard.";

        public static string API_Status = string.Empty; // Résultats de l'appel API
        public static string API_Modules = string.Empty; // Résultats de l'appel API
        public static string API_Version = string.Empty; // Résultats de l'appel API

        public static string API_Url = "https://apps.git-cad.ch/compagnon/api/get-modules/";
        public static string API_LogURL = $"https://apps.git-cad.ch/compagnon/api/log?level=info&message=";

        // Dépôt Github
        public static string Github_User = "GITCAD-Sarl";
        public static string Github_Repo = "BIMnorm_Setup";
        public static string Github_Path = ""; // Exemple : "build" ou "" si racine

        // Revit
        public static string Revit_PathApplication = Path.GetDirectoryName(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName);
        public static string Revit_PathResources = Path.Combine(Revit_PathApplication, "Resources");
        public static string Revit_PathAddins = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "/Autodesk/Revit/Addins/2023/";
        public static string Revit_PathDefaultDynamoFolder = "C:\\Users\\Public\\Documents\\GITCAD\\BIMnorm\\R23-Fra\\Scripts\\";

        public static UIControlledApplication RevitApp = null;
        public static ExternalCommandData RevitCommandData = null;

        //public const Int32 BUFFER_SIZE = 512; // Unmodifiable
        //public static String FILE_NAME = "Output.txt"; // Modifiable
        //public static readonly String CODE_PREFIX = "US-"; // Unmodifiable
    }

    public static class EncryptionKeys
    {
        // Clé de chiffrement de 256 bits (32 bytes) en base64
        public static readonly byte[] EncryptionKey = Convert.FromBase64String("rN+g3mP8ls+sN7GnA9g1Tjw9gRnF93hFj6Gq1/r3eGs=");

        // Vecteur d'initialisation de 128 bits (16 bytes) en base64
        public static readonly byte[] InitializationVector = Convert.FromBase64String("A8Fr2jk1Lg7Hc8N3k1NrOA==");
    }
}
