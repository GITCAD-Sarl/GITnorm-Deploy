﻿using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using BIMnorm.Revit2023.App.License;
using System.Windows;

namespace BIMnorm.Revit2023.Commands
{
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]

    public class Command_ChangeLevelElements : IExternalCommand
    {
        /// <summary>
        /// Point d’entrée d’une commande externe Revit.
        /// Vérifie la validité de la licence avant d’exécuter la logique principale de la commande.
        /// </summary>
        /// <param name="commandData">Contient les données et objets liés à la session Revit.</param>
        /// <param name="message">Message d’erreur retourné à Revit en cas d’échec (non utilisé ici).</param>
        /// <param name="elements">Éléments potentiellement impliqués en cas d’échec (non utilisé ici).</param>
        /// <returns>
        /// <see cref="Result.Succeeded"/> si la licence est valide et que la commande s'exécute correctement ;
        /// <see cref="Result.Failed"/> en cas d’échec de la vérification de licence ou d'erreur.
        /// </returns>
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            // --- Check license ---
            Result licenseCheck = LicenseManager.Validate("Gratuit");
            if (licenseCheck != Result.Succeeded) return licenseCheck;

            // --- Command main logic ---
            MessageBox.Show("La commande Command_ChangeLevelElements n'est pas implémentée");

            return Result.Succeeded;
        }
    }
}
