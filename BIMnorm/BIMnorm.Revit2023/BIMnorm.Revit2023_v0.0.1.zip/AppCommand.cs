﻿using Autodesk.Revit.UI;

//using Autodesk.Windows;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;
using BIMnorm.Revit2023.App.Revit;
using BIMnorm.Revit2023.App.API;

namespace BIMnorm.Revit2023
{
    /// <summary>
    /// Classe principale de l'application externe Revit.
    /// </summary>
    internal class AppCommand : IExternalApplication
    {
        public Result OnStartup(UIControlledApplication application)
        {
#if DEBUG
            GlobalVariables.Global_DebugMode = true;
#endif

            try
            {
                ApiConnection.CheckApiAndStoreResults();

                ApiHttpHelper.SendLogToServer(
                    "GUID : " + GlobalVariables.Global_userGuid + " | API résultat : " + GlobalVariables.API_Status
                );

                if (!string.IsNullOrWhiteSpace(GlobalVariables.API_Status)
                    && !string.IsNullOrWhiteSpace(GlobalVariables.API_Version)
                    && string.Equals(GlobalVariables.API_Status, "ok", StringComparison.OrdinalIgnoreCase)
                    && ApiUtilities.ContainsValueInCsv(GlobalVariables.API_Version, "23"))
                {
                    CreateRibbonTab_BIMnorm.Main(application);
                    return Result.Succeeded;
                }
                else
                {
                    ApiRequestAccess.OpenMicrosoftFormsRequest();
                    return Result.Cancelled;
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(
                    "Erreur critique lors du démarrage de l'add-in : " + ex.Message,
                    "Erreur API",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
                return Result.Failed;
            }
        }

        public Result OnShutdown(UIControlledApplication application)
        {
            return Result.Succeeded;
        }

    }

    public class CheckUpdates
    {
        static async Task Main(string[] args)
        {
            // Définir les paramètres nécessaires
            string connectionString = "Server=myServerAddress;Database=myDataBase;User Id=myUsername;Password=myPassword;";
            string currentVersion = "1.0.0"; // Version actuelle de l'application
            string downloadUrl = "https://github.com/user/repo/releases/download/v2.0.0/installer.exe"; // URL de téléchargement
            string setupFilePath = @"C:\Temp\installer.exe"; // Chemin où le setup sera sauvegardé

            // Créer une instance de la classe Updater
            Updater updater = new Updater(connectionString, currentVersion, downloadUrl, setupFilePath);

            // Appeler la méthode de mise à jour asynchrone
            await updater.CheckAndUpdateAsync();

            Console.WriteLine("Vérification de mise à jour terminée.");
        }
    }

    public class CreateRibbonTab_BIMnorm
    {

        public static void Main(UIControlledApplication application)
        {
            //Creation onglet (RibbonTab)
            var RibbonBIMnorm = "BIMnorm";
            application.CreateRibbonTab(RibbonBIMnorm);

            //Creation des groupes de fonctions (RibbonPanel)
            Create_RibbonPanel_Help(application, RibbonBIMnorm);
            Create_RibbonPanel_Affichage(application, RibbonBIMnorm);
            Create_RibbonPanel_Modelisation(application, RibbonBIMnorm);
            Create_RibbonPanel_General(application, RibbonBIMnorm);
            Create_RibbonPanel_IFC(application, RibbonBIMnorm);

        }

        // -- Help --

        public static void Create_RibbonPanel_Help(UIControlledApplication application, string tabName)
        {
            //Creation groupe de commandes
            var panelName = "Information";

            RevitRibbonHelper.CreateNewPanel(application, tabName, panelName);

            //Selection du groupe de commandes
            RibbonPanel ribbonPanel = null;
            ribbonPanel = application.GetRibbonPanels(tabName).FirstOrDefault(p => p.Name == panelName);

            //Creation des boutons dans le groupe de commandes
            RevitRibbonHelper.CreatePushButtonWithToolTip(ribbonPanel, "BIMnorm.Revit2023.Commands.Command_HelpButton", "HelpButton", "Aide", "Besoin d'aide ?", "BIMnorm.Revit2023.resources.icons.Img32x32_Help.png");

        }

        // -- Affichage --

        public static void Create_RibbonPanel_Affichage(UIControlledApplication application, string tabName)
        {
            //Creation groupe de commandes
            var panelName = "Affichage";

            RevitRibbonHelper.CreateNewPanel(application, tabName, panelName);

            //Selection du groupe de commandes
            RibbonPanel ribbonPanel = null;
            ribbonPanel = application.GetRibbonPanels(tabName).FirstOrDefault(p => p.Name == panelName);

            //Creation des boutons dans le groupe de commandes

            Create_StackedGroup_Affichage1(ribbonPanel);
            Create_StackedGroup_Affichage2(ribbonPanel);
            //Create_StackedGroup_Affichage3(ribbonPanel);

        }

        public static void Create_StackedGroup_Affichage1(RibbonPanel panel)
        {
            string assemFullName = Assembly.GetExecutingAssembly().Location;
            string assemPath = Path.GetDirectoryName(assemFullName);

            // Création d'un PulldownButton
            PulldownButtonData itemData1 = new PulldownButtonData("GroupRangeFarClip", "Plage/profondeur");
            itemData1.ToolTip = "";  // Tooltip
            itemData1.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupRangeFarClip.png");
            itemData1.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupRangeFarClip.png");

            // Création d'un PulldownButton
            PulldownButtonData itemData2 = new PulldownButtonData("GroupRevitPoints", "Points Revit");
            itemData2.ToolTip = "";  // Tooltip
            itemData2.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupRevitPoints.png");
            itemData2.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupRevitPoints.png");

            // Création d'un PulldownButton
            PulldownButtonData itemData3 = new PulldownButtonData("GroupTinlinePoints", "Points TinLine");
            itemData3.ToolTip = "";  // Tooltip
            itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupTinlinePoints.png");
            itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupTinlinePoints.png");

            // Ajoute les boutons PushButton et PulldownButton dans un groupe empilé
            IList<RibbonItem> stackedGroup1 = panel.AddStackedItems(itemData1, itemData2, itemData3);

            // Récupère le PulldownButton et l'ajout au groupe
            PulldownButton group1 = stackedGroup1[0] as PulldownButton;

            // Récupère le PulldownButton et l'ajout au groupe
            PulldownButton group2 = stackedGroup1[1] as PulldownButton;

            // Récupère le PulldownButton et l'ajout au groupe
            PulldownButton group3 = stackedGroup1[2] as PulldownButton;

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData11 = new PushButtonData("SectionFarClipManager", "Profondeur de coupe", assemFullName, "BIMnorm.Revit2023.Commands.Command_SectionFarClipManager");
            PushButton item11 = group1.AddPushButton(itemData11) as PushButton;
            item11.ToolTip = "";  // Tooltip
            item11.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");
            item11.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData12 = new PushButtonData("ViewRangeManager", "Plage de vue", assemFullName, "BIMnorm.Revit2023.Commands.Command_ViewRangeManager");
            PushButton item12 = group1.AddPushButton(itemData12) as PushButton;
            item12.ToolTip = "";  // Tooltip
            item12.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ViewRangeManager.png");
            item12.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ViewRangeManager.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData21 = new PushButtonData("ShowAllPoints", "Afficher tout", assemFullName, "BIMnorm.Revit2023.Commands.Command_AllPoints");
            PushButton item21 = group2.AddPushButton(itemData21) as PushButton;
            item21.ToolTip = "";  // Tooltip
            //item21.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_AllPoints.png");
            //item21.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_AllPoints.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData22 = new PushButtonData("ShowBasePoint", "Afficher point de base", assemFullName, "BIMnorm.Revit2023.Commands.Command_BasePoint");
            PushButton item22 = group2.AddPushButton(itemData22) as PushButton;
            item22.ToolTip = "";  // Tooltip
            //item22.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_BasePoint.png");
            //item22.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_BasePoint.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData23 = new PushButtonData("ShowTopographyPoint", "Afficher point topographique", assemFullName, "BIMnorm.Revit2023.Commands.Command_TopographyPoint");
            PushButton item23 = group2.AddPushButton(itemData23) as PushButton;
            item23.ToolTip = "";  // Tooltip
            //item23.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_TopographyPoint.png");
            //item23.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_TopographyPoint.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData24 = new PushButtonData("ShowOriginPoint", "Afficher point d'origine", assemFullName, "BIMnorm.Revit2023.Commands.Command_OriginPoint");
            PushButton item24 = group2.AddPushButton(itemData24) as PushButton;
            item24.ToolTip = "";  // Tooltip
            //item24.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_OriginPoint.png");
            //item24.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_OriginPoint.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData25 = new PushButtonData("HideAllPoints", "Masquer tout", assemFullName, "BIMnorm.Revit2023.Commands.Command_AllPoints");
            PushButton item25 = group2.AddPushButton(itemData25) as PushButton;
            item25.ToolTip = "";  // Tooltip
            //item21.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_AllPoints.png");
            //item21.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_AllPoints.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData26 = new PushButtonData("HideShowBasePoint", "Masquer point de base", assemFullName, "BIMnorm.Revit2023.Commands.Command_BasePoint");
            PushButton item26 = group2.AddPushButton(itemData26) as PushButton;
            item26.ToolTip = "";  // Tooltip
            //item22.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_BasePoint.png");
            //item22.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_BasePoint.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData27 = new PushButtonData("HideTopographyPoint", "Masquer point topographique", assemFullName, "BIMnorm.Revit2023.Commands.Command_TopographyPoint");
            PushButton item27 = group2.AddPushButton(itemData27) as PushButton;
            item27.ToolTip = "";  // Tooltip
            //item23.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_TopographyPoint.png");
            //item23.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_TopographyPoint.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData28 = new PushButtonData("HideOriginPoint", "Masquer point d'origine", assemFullName, "BIMnorm.Revit2023.Commands.Command_OriginPoint");
            PushButton item28 = group2.AddPushButton(itemData28) as PushButton;
            item28.ToolTip = "";  // Tooltip
            //item24.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_OriginPoint.png");
            //item24.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_OriginPoint.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData31 = new PushButtonData("ShowTinlinePoints", "Afficher tout", assemFullName, "BIMnorm.Revit2023.Commands.Command_TinlinePoints");
            PushButton item31 = group3.AddPushButton(itemData31) as PushButton;
            item31.ToolTip = "";  // Tooltip
            //item24.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_OriginPoint.png");
            //item24.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_OriginPoint.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData32 = new PushButtonData("HideTinlinePoints", "Masquer tout", assemFullName, "BIMnorm.Revit2023.Commands.Command_TinlinePoints");
            PushButton item32 = group3.AddPushButton(itemData32) as PushButton;
            item32.ToolTip = "";  // Tooltip
            //item24.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_OriginPoint.png");
            //item24.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_OriginPoint.png");
        }

        public static void Create_StackedGroup_Affichage2(RibbonPanel panel)
        {
            string assemFullName = Assembly.GetExecutingAssembly().Location;
            string assemPath = Path.GetDirectoryName(assemFullName);

            // Création d'un PushButton
            PushButtonData itemData1 = new PushButtonData("CopyFilters", "Copier", assemFullName, "BIMnorm.Revit2023.Commands.Command_CopyFilters");
            itemData1.ToolTip = "";  // Tooltip
            itemData1.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_CopyFilters.png");
            itemData1.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_CopyFilters.png");

            // Création d'un PulldownButton
            PulldownButtonData itemData2 = new PulldownButtonData("GroupFreeze", "Geler");
            itemData2.ToolTip = "";  // Tooltip
            itemData2.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupFreeze.png");
            itemData2.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupFreeze.png");

            // Création d'un PushButton
            PushButtonData itemData3 = new PushButtonData("Command_ResetHiddenElements", "Réinitialiser", assemFullName, "BIMnorm.Revit2023.Commands.Command_ResetHiddenElements");
            itemData3.ToolTip = "";  // Tooltip
            itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ResetHiddenElements.png");
            itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ResetHiddenElements.png");

            //// Création d'un PushButton
            //PushButtonData itemData2 = new PushButtonData("HideLevelsGrids", "GérerQN", assemFullName, "BIMnorm.Revit2023.Commands.Command_HideLevelsGrids");
            //itemData2.ToolTip = "";  // Tooltip
            //itemData2.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_HideLevelsGrids.png");
            //itemData2.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_HideLevelsGrids.png");

            //// Création d'un PushButton
            //PushButtonData itemData3 = new PushButtonData("HideFilters", "GérerF", assemFullName, "BIMnorm.Revit2023.Commands.Command_HideFilters");
            //itemData3.ToolTip = "";  // Tooltip
            //itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_HideFilters.png");
            //itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_HideFilters.png");

            // Ajoute les boutons PushButton et PulldownButton dans un groupe empilé
            IList<RibbonItem> stackedGroup1 = panel.AddStackedItems(itemData1, itemData2, itemData3);

            // Récupère le PulldownButton et l'ajout au groupe
            PulldownButton group1 = stackedGroup1[1] as PulldownButton;

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData11 = new PushButtonData("FreezeLevelsGrids", "Quadrillages et niveaux", assemFullName, "BIMnorm.Revit2023.Commands.Command_HideLevelsGrids");
            PushButton item11 = group1.AddPushButton(itemData11) as PushButton;
            item11.ToolTip = "";  // Tooltip
            //item11.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");
            //item11.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData12 = new PushButtonData("FreezeFilters", "Filtres", assemFullName, "BIMnorm.Revit2023.Commands.Command_HideFilters");
            PushButton item12 = group1.AddPushButton(itemData12) as PushButton;
            item12.ToolTip = "";  // Tooltip
            //item11.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");
            //item11.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");
        }

        //public static void Create_StackedGroup_Affichage3(RibbonPanel panel)
        //{
        //    string assemFullName = Assembly.GetExecutingAssembly().Location;
        //    string assemPath = Path.GetDirectoryName(assemFullName);

        //    // Création d'un PushButton
        //    PushButtonData itemData1 = new PushButtonData("Command_ResetHiddenElements", "ResetElementsHidden", assemFullName, "BIMnorm.Revit2023.Commands.Command_ResetHiddenElements");
        //    itemData1.ToolTip = "";  // Tooltip
        //    itemData1.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ResetHiddenElements.png");
        //    itemData1.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ResetHiddenElements.png");

        //    // Création d'un PushButton vide
        //    PushButtonData itemData2 = new PushButtonData("NotImplemented001", "\u200B​", assemFullName, "BIMnorm.Revit2023.Commands.");            
        //    //itemData2.ToolTip = "";  // Tooltip
        //    //itemData2.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_Default.png");
        //    //itemData2.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_Default.png");

        //    // Création d'un PushButton vide
        //    PushButtonData itemData3 = new PushButtonData("NotImplemented002", "\u200B", assemFullName, "BIMnorm.Revit2023.Commands.");            
        //    //itemData3.ToolTip = "";  // Tooltip            
        //    //itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_Default.png");
        //    //itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_Default.png");

        //    // Ajoute les boutons PushButton et PulldownButton dans un groupe empilé
        //    IList<RibbonItem> stackedGroup1 = panel.AddStackedItems(itemData1, itemData2, itemData3);

        //    // Récupère les PushButton associés à itemData2 et itemData3 et les désactivent
        //    PushButton item2 = stackedGroup1.OfType<PushButton>().FirstOrDefault(p => p.Name == itemData2.Name);
        //    item2.Enabled = false;
        //    PushButton item3 = stackedGroup1.OfType<PushButton>().FirstOrDefault(p => p.Name == itemData3.Name);                        
        //    item3.Enabled = false;                      
            
        //}

        // -- Modélisation --

        public static void Create_RibbonPanel_Modelisation(UIControlledApplication application, string tabName)
        {
            //Creation groupe de commandes
            var panelName = "Modélisation";

            RevitRibbonHelper.CreateNewPanel(application, tabName, panelName);

            //Selection du groupe de commandes
            RibbonPanel ribbonPanel = null;
            ribbonPanel = application.GetRibbonPanels(tabName).FirstOrDefault(p => p.Name == panelName);

            //Creation des boutons dans le groupe de commandes
            Create_StackedGroup_Modelisation1(ribbonPanel);
            //Create_StackedGroup_Modelisation2(ribbonPanel);
            //Create_StackedGroup_Modelisation3(ribbonPanel);
            //Create_StackedGroup_Modelisation4(ribbonPanel);

        }

        public static void Create_StackedGroup_Modelisation1(RibbonPanel panel)
        {
            string assemFullName = Assembly.GetExecutingAssembly().Location;
            string assemPath = Path.GetDirectoryName(assemFullName);

            // Création d'un PulldownButton
            PulldownButtonData itemData1 = new PulldownButtonData("GroupWorksets", "Sous-projets");
            itemData1.ToolTip = "";  // Tooltip
            itemData1.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupWorksets.png");
            itemData1.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupWorksets.png");

            // Création d'un PulldownButton
            PulldownButtonData itemData2 = new PulldownButtonData("GroupFamilies", "Familles");
            itemData2.ToolTip = "";  // Tooltip
            itemData2.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupFamilies.png");
            itemData2.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupFamilies.png");

            // Création d'un PulldownButton
            PulldownButtonData itemData3 = new PulldownButtonData("GroupInstances", "Occurrences");
            itemData3.ToolTip = "";  // Tooltip
            itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupInstances.png");
            itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupInstances.png");

            // Ajoute les boutons PushButton et PulldownButton dans un groupe empilé
            IList<RibbonItem> stackedGroup1 = panel.AddStackedItems(itemData1, itemData2, itemData3);

            // Récupère le PulldownButton et l'ajout au groupe
            PulldownButton group1 = stackedGroup1[0] as PulldownButton;

            // Récupère le PulldownButton et l'ajout au groupe
            PulldownButton group2 = stackedGroup1[1] as PulldownButton;

            // Récupère le PulldownButton et l'ajout au groupe
            PulldownButton group3 = stackedGroup1[2] as PulldownButton;

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData11 = new PushButtonData("DefineActive", "Définir", assemFullName, "BIMnorm.Revit2023.Commands.Command_DefineActiveWorkset");
            PushButton item11 = group1.AddPushButton(itemData11) as PushButton;
            item11.ToolTip = "";  // Tooltip
            //item11.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");
            //item11.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData12 = new PushButtonData("AssociateActive", "Associer", assemFullName, "BIMnorm.Revit2023.Commands.Command_AssociateActiveWorkset");
            PushButton item12 = group1.AddPushButton(itemData12) as PushButton;
            item12.ToolTip = "";  // Tooltip
            //item11.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");
            //item11.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData13 = new PushButtonData("CopyElementsWithAssociatedWorkset", "Copier éléments", assemFullName, "BIMnorm.Revit2023.Commands.Command_CopyElementsWithAssociatedWorkset");
            PushButton item13 = group1.AddPushButton(itemData13) as PushButton;
            item13.ToolTip = "";  // Tooltip
            //item11.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");
            //item11.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");

            //// Création d'un PushButton
            //PushButtonData itemData1 = new PushButtonData("DefineActive", "DefinirSAO", assemFullName, "BIMnorm.Revit2023.Commands.Command_DefineActiveWorkset");
            //itemData1.ToolTip = "";  // Tooltip
            //itemData1.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_DefineActiveWorkset.png");
            //itemData1.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_DefineActiveWorkset.png");

            //// Création d'un PushButton
            //PushButtonData itemData2 = new PushButtonData("AssociateActiveWorkset", "AssocierSAO", assemFullName, "BIMnorm.Revit2023.Commands.Command_AssociateActiveWorkset");
            //itemData2.ToolTip = "";  // Tooltip
            //itemData2.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_AssociateActiveWorkset.png");
            //itemData2.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_AssociateActiveWorkset.png");

            //// Création d'un PushButton
            //PushButtonData itemData3 = new PushButtonData("CopyElementsWithAssociatedWorkset", "CopierOCSA", assemFullName, "BIMnorm.Revit2023.Commands.Command_CopyElementsWithAssociatedWorkset");
            //itemData3.ToolTip = "";  // Tooltip
            //itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_CopyElementsWithAssociatedWorkset.png");
            //itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_CopyElementsWithAssociatedWorkset.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData21 = new PushButtonData("CreateType", "Créer types", assemFullName, "BIMnorm.Revit2023.Commands.Command_CreateType");
            PushButton item21 = group2.AddPushButton(itemData21) as PushButton;
            item21.ToolTip = "";  // Tooltip
            //item11.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");
            //item11.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData22 = new PushButtonData("RenameFamiliesAndTypes", "Renommer familles et types", assemFullName, "BIMnorm.Revit2023.Commands.Command_RenameFamiliesAndTypes");
            PushButton item22 = group2.AddPushButton(itemData22) as PushButton;
            item22.ToolTip = "";  // Tooltip
            //item11.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");
            //item11.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData31 = new PushButtonData("FlipElements", "Retourner", assemFullName, "BIMnorm.Revit2023.Commands.Command_FlipElements");
            PushButton item31 = group3.AddPushButton(itemData31) as PushButton;
            item31.ToolTip = "";  // Tooltip
            //item11.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");
            //item11.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData32 = new PushButtonData("ReplaceElements", "Remplacer", assemFullName, "BIMnorm.Revit2023.Commands.Command_ReplaceElements");
            PushButton item32 = group3.AddPushButton(itemData32) as PushButton;
            item32.ToolTip = "";  // Tooltip
            //item11.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");
            //item11.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData33 = new PushButtonData("RotateElements", "Tourner", assemFullName, "BIMnorm.Revit2023.Commands.Command_RotateElements");
            PushButton item33 = group3.AddPushButton(itemData33) as PushButton;
            item33.ToolTip = "";  // Tooltip
            //item11.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");
            //item11.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData34 = new PushButtonData("ColorTags", "Colorier étiquettes", assemFullName, "BIMnorm.Revit2023.Commands.Command_ColorTags");
            PushButton item34 = group3.AddPushButton(itemData34) as PushButton;
            item33.ToolTip = "";  // Tooltip
            //item11.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");
            //item11.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_SectionFarClipManager.png");
        }

        //public static void Create_StackedGroup_Modelisation2(RibbonPanel panel)
        //{
        //    string assemFullName = Assembly.GetExecutingAssembly().Location;
        //    string assemPath = Path.GetDirectoryName(assemFullName);

        //    // Création d'un PushButton
        //    PushButtonData itemData1 = new PushButtonData("CreateType", "CréerT", assemFullName, "BIMnorm.Revit2023.Commands.Command_CreateType");
        //    itemData1.ToolTip = "";  // Tooltip
        //    itemData1.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_CreateType.png");
        //    itemData1.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_CreateType.png");

        //    // Création d'un PushButton
        //    PushButtonData itemData2 = new PushButtonData("RenameFamiliesAndTypes", "RenommerFT", assemFullName, "BIMnorm.Revit2023.Commands.Command_RenameFamiliesAndTypes");
        //    itemData2.ToolTip = "";  // Tooltip
        //    itemData2.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_RenameFamiliesAndTypes.png");
        //    itemData2.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_RenameFamiliesAndTypes.png");

        //    // Création d'un PushButton vide
        //    PushButtonData itemData3 = new PushButtonData("NotImplemented003", "\u200B", assemFullName, "BIMnorm.Revit2023.Commands.");
        //    //itemData3.ToolTip = "";  // Tooltip
        //    //itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_Default.png");
        //    //itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_Default.png");

        //    // Ajoute les boutons PushButton et PulldownButton dans un groupe empilé
        //    IList<RibbonItem> stackedGroup1 = panel.AddStackedItems(itemData1, itemData2, itemData3);

        //    // Récupère le PushButton associé à itemData3 et le désactive
        //    PushButton item3 = stackedGroup1.OfType<PushButton>().FirstOrDefault(p => p.Name == itemData3.Name);
        //    item3.Enabled = false;

        //}

        //public static void Create_StackedGroup_Modelisation3(RibbonPanel panel)
        //{
        //    string assemFullName = Assembly.GetExecutingAssembly().Location;
        //    string assemPath = Path.GetDirectoryName(assemFullName);

        //    // Création d'un PushButton
        //    PushButtonData itemData1 = new PushButtonData("FlipElements", "RetournerO", assemFullName, "BIMnorm.Revit2023.Commands.Command_FlipElements");
        //    itemData1.ToolTip = "";  // Tooltip
        //    itemData1.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_FlipElements.png");
        //    itemData1.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_FlipElements.png");

        //    // Création d'un PushButton
        //    PushButtonData itemData2 = new PushButtonData("ReplaceElements", "RemplacerO", assemFullName, "BIMnorm.Revit2023.Commands.Command_ReplaceElements");
        //    itemData2.ToolTip = "";  // Tooltip
        //    itemData2.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ReplaceElements.png");
        //    itemData2.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ReplaceElements.png");

        //    // Création d'un PushButton
        //    PushButtonData itemData3 = new PushButtonData("RotateElements", "TournerO", assemFullName, "BIMnorm.Revit2023.Commands.Command_RotateElements");
        //    itemData3.ToolTip = "";  // Tooltip
        //    itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_RotateElements.png");
        //    itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_RotateElements.png");

        //    // Ajoute les boutons PushButton et PulldownButton dans un groupe empilé
        //    IList<RibbonItem> stackedGroup1 = panel.AddStackedItems(itemData1, itemData2, itemData3);
        //}

        //public static void Create_StackedGroup_Modelisation4(RibbonPanel panel)
        //{
        //    string assemFullName = Assembly.GetExecutingAssembly().Location;
        //    string assemPath = Path.GetDirectoryName(assemFullName);

        //    // Création d'un PushButton
        //    PushButtonData itemData1 = new PushButtonData("ChangeLevelElements", "RéférencerON", assemFullName, "BIMnorm.Revit2023.Commands.Command_ChangeLevelElements");
        //    itemData1.ToolTip = "";  // Tooltip
        //    itemData1.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ChangeLevelElements.png");
        //    itemData1.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ChangeLevelElements.png");

        //    // Création d'un PushButton
        //    PushButtonData itemData2 = new PushButtonData("CutSystemsLevel", "CouperSN", assemFullName, "BIMnorm.Revit2023.Commands.Command_CutSystemsLevel");
        //    itemData2.ToolTip = "";  // Tooltip
        //    itemData2.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_CutSystemsLevel.png");
        //    itemData2.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_CutSystemsLevel.png");

        //    // Création d'un PushButton
        //    PushButtonData itemData3 = new PushButtonData("AddElementsOnExisting", "AjouterOSO", assemFullName, "BIMnorm.Revit2023.Commands.Command_AddElementsOnExisting");
        //    itemData3.ToolTip = "";  // Tooltip
        //    itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_AddElementsOnExisting.png");
        //    itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_AddElementsOnExisting.png");

        //    // Ajoute les boutons PushButton et PulldownButton dans un groupe empilé
        //    IList<RibbonItem> stackedGroup1 = panel.AddStackedItems(itemData1, itemData2, itemData3);
        //}

        // -- Général --

        public static void Create_RibbonPanel_General(UIControlledApplication application, string tabName)
        {
            //Creation groupe de commandes
            var panelName = "Général";

            RevitRibbonHelper.CreateNewPanel(application, tabName, panelName);

            //Selection du groupe de commandes
            RibbonPanel ribbonPanel = null;
            ribbonPanel = application.GetRibbonPanels(tabName).FirstOrDefault(p => p.Name == panelName);

            //Creation des boutons dans le groupe de commandes
            //Create_StackedGroup_General1(ribbonPanel);
            Create_StackedGroup_General2(ribbonPanel);
            //Create_StackedGroup_General3(ribbonPanel);

        }

        //public static void Create_StackedGroup_General1(RibbonPanel panel)
        //{
        //    string assemFullName = Assembly.GetExecutingAssembly().Location;
        //    string assemPath = Path.GetDirectoryName(assemFullName);

        //    // Création d'un PulldownButton
        //    PulldownButtonData itemData1 = new PulldownButtonData("GroupClean", "Nettoyer");
        //    itemData1.ToolTip = "";  // Tooltip
        //    itemData1.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupClean.png");
        //    itemData1.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupClean.png");

        //    // Création d'un PulldownButton
        //    PulldownButtonData itemData2 = new PulldownButtonData("GroupParameters", "Paramètres");
        //    itemData2.ToolTip = "";  // Tooltip
        //    itemData2.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupParameters.png");
        //    itemData2.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupParameters.png");

        //    // Création d'un PushButton
        //    PushButtonData itemData3 = new PushButtonData("FillParameter", "RenseignerP", assemFullName, "BIMnorm.Revit2023.Commands.Command_FillParameter");
        //    itemData3.ToolTip = "";  // Tooltip
        //    itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_FillParameter.png");
        //    itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_FillParameter.png");

        //    // Ajoute les boutons PushButton et PulldownButton dans un groupe empilé
        //    IList<RibbonItem> stackedGroup1 = panel.AddStackedItems(itemData1, itemData2, itemData3);

        //    // Récupère le PulldownButton et l'ajout au groupe
        //    PulldownButton group1 = stackedGroup1[0] as PulldownButton;

        //    // Ajout de sous-boutons au PulldownButton
        //    PushButtonData itemData11 = new PushButtonData("CleanModel1", "Nettoyer v1", assemFullName, "BIMnorm.Revit2023.Commands.Command_CleanModel1");
        //    PushButton item11 = group1.AddPushButton(itemData11) as PushButton;
        //    item11.ToolTip = "";  // Tooltip
        //    item11.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_CleanModel1.png");
        //    item11.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_CleanModel1.png");

        //    // Ajout de sous-boutons au PulldownButton
        //    PushButtonData itemData12 = new PushButtonData("CleanModel2", "Nettoyer v2", assemFullName, "BIMnorm.Revit2023.Commands.Command_CleanModel2");
        //    PushButton item12 = group1.AddPushButton(itemData12) as PushButton;
        //    item12.ToolTip = "";  // Tooltip
        //    item12.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_CleanModel2.png");
        //    item12.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_CleanModel2.png");


        //    // Récupère le PulldownButton et l'ajout au groupe
        //    PulldownButton group2 = stackedGroup1[1] as PulldownButton;

        //    // Ajout de sous-boutons au PulldownButton
        //    PushButtonData itemData21 = new PushButtonData("TransferParameters", "Transférer paramètres", assemFullName, "BIMnorm.Revit2023.Commands.Command_TransferParameters");
        //    PushButton item21 = group2.AddPushButton(itemData21) as PushButton;
        //    item21.ToolTip = "";  // Tooltip
        //    item21.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_TransferParameters.png");
        //    item21.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_TransferParameters.png");

        //    // Ajout de sous-boutons au PulldownButton
        //    PushButtonData itemData22 = new PushButtonData("DeleteParameters", "Supprimer paramètres", assemFullName, "BIMnorm.Revit2023.Commands.Command_DeleteParameters");
        //    PushButton item22 = group2.AddPushButton(itemData22) as PushButton;
        //    item22.ToolTip = "";  // Tooltip
        //    item22.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_DeleteParameters.png");
        //    item22.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_DeleteParameters.png");

        //}

        public static void Create_StackedGroup_General2(RibbonPanel panel)
        {
            string assemFullName = Assembly.GetExecutingAssembly().Location;
            string assemPath = Path.GetDirectoryName(assemFullName);

            // Création d'un PushButton
            PushButtonData itemData1 = new PushButtonData("PinElements", "Verrouiller", assemFullName, "BIMnorm.Revit2023.Commands.Command_PinElements");
            itemData1.ToolTip = "";  // Tooltip
            itemData1.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_PinElements.png");
            itemData1.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_PinElements.png");

            // Création d'un PushButton
            PushButtonData itemData2 = new PushButtonData("Create3dLinkedElements", "Zone de sélection+", assemFullName, "BIMnorm.Revit2023.Commands.Command_Create3dLinkedElements");
            itemData2.ToolTip = "";  // Tooltip
            itemData2.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_Create3dLinkedElements.png");
            itemData2.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_Create3dLinkedElements.png");

            // Création d'un PulldownButton
            PulldownButtonData itemData3 = new PulldownButtonData("GroupParameters", "Paramètres");
            itemData3.ToolTip = "";  // Tooltip
            itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupParameters.png");
            itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_GroupParameters.png");

            //// Création d'un PushButton
            //PushButtonData itemData3 = new PushButtonData("ExportImages", "ExporterI", assemFullName, "BIMnorm.Revit2023.Commands.Command_ExportImages");
            //itemData3.ToolTip = "";  // Tooltip
            //itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ExportImages.png");
            //itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ExportImages.png");

            // Ajoute les boutons PushButton et PulldownButton dans un groupe empilé
            IList<RibbonItem> stackedGroup1 = panel.AddStackedItems(itemData1, itemData2, itemData3);

            // Récupère le PulldownButton et l'ajout au groupe
            PulldownButton group2 = stackedGroup1[2] as PulldownButton;

            // Ajout de sous-boutons au PulldownButton
            PushButtonData itemData31 = new PushButtonData("TransferParameters", "Transférer", assemFullName, "BIMnorm.Revit2023.Commands.Command_TransferParameters");
            PushButton item31 = group2.AddPushButton(itemData31) as PushButton;
            item31.ToolTip = "";  // Tooltip
            //item31.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_TransferParameters.png");
            //item31.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_TransferParameters.png");
        }

        //public static void Create_StackedGroup_General3(RibbonPanel panel)
        //{
        //    string assemFullName = Assembly.GetExecutingAssembly().Location;
        //    string assemPath = Path.GetDirectoryName(assemFullName);

        //    // Création d'un PushButton
        //    PushButtonData itemData1 = new PushButtonData("ImportExportExcel", "IM/EXport Excel", assemFullName, "BIMnorm.Revit2023.Commands.Command_ImportExportExcel");
        //    itemData1.ToolTip = "";  // Tooltip
        //    itemData1.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ImportExportExcel.png");
        //    itemData1.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ImportExportExcel.png");

        //    // Création d'un PushButton
        //    PushButtonData itemData2 = new PushButtonData("IdsModelChecker", "IDS Revit", assemFullName, "BIMnorm.Revit2023.Commands.Command_IdsModelChecker");
        //    itemData2.ToolTip = "";  // Tooltip
        //    itemData2.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_IdsModelChecker.png");
        //    itemData2.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_IdsModelChecker.png");

        //    // Création d'un PushButton
        //    PushButtonData itemData3 = new PushButtonData("FillParametersLevel", "RenseignerPN", assemFullName, "BIMnorm.Revit2023.Commands.Command_FillParametersLevel");
        //    itemData3.ToolTip = "";  // Tooltip
        //    itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_FillParametersLevel.png");
        //    itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_FillParametersLevel.png");

        //    // Ajoute les boutons PushButton et PulldownButton dans un groupe empilé
        //    IList<RibbonItem> stackedGroup1 = panel.AddStackedItems(itemData1, itemData2, itemData3);
        //}

        // -- IFC --

        public static void Create_RibbonPanel_IFC(UIControlledApplication application, string tabName)
        {
            //Creation groupe de commandes
            var panelName = "IFC";

            RevitRibbonHelper.CreateNewPanel(application, tabName, panelName);

            //Selection du groupe de commandes
            RibbonPanel ribbonPanel = null;
            ribbonPanel = application.GetRibbonPanels(tabName).FirstOrDefault(p => p.Name == panelName);

            //Creation des boutons dans le groupe de commandes
            Create_StackedGroup_IFC1(ribbonPanel);

        }

        public static void Create_StackedGroup_IFC1(RibbonPanel panel)
        {
            string assemFullName = Assembly.GetExecutingAssembly().Location;
            string assemPath = Path.GetDirectoryName(assemFullName);

            //// Création d'un PushButton
            //PushButtonData itemData1 = new PushButtonData("ExportIfc", "Exporter IFC", assemFullName, "BIMnorm.Revit2023.Commands.Command_ExportIfc");
            //itemData1.ToolTip = "";  // Tooltip
            //itemData1.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ExportIfc.png");
            //itemData1.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_ExportIfc.png");

            //// Création d'un PushButton
            //PushButtonData itemData2 = new PushButtonData("EditIfc", "Editer IFC", assemFullName, "BIMnorm.Revit2023.Commands.Command_EditIfc");
            //itemData2.ToolTip = "";  // Tooltip
            //itemData2.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_EditIfc.png");
            //itemData2.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_EditIfc.png");

            // Création d'un PushButton
            PushButtonData itemData1 = new PushButtonData("CleanIfc", "Nettoyeur", assemFullName, "BIMnorm.Revit2023.Commands.Command_CleanIfc");
            itemData1.ToolTip = "";  // Tooltip
            itemData1.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_CleanIfc.png");
            itemData1.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_CleanIfc.png");

            // Création d'un PushButton vide
            PushButtonData itemData2 = new PushButtonData("NotImplemented004", "\u200B", assemFullName, "BIMnorm.Revit2023.Commands.");
            //itemData3.ToolTip = "";  // Tooltip
            //itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_Default.png");
            //itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_Default.png");

            // Création d'un PushButton vide
            PushButtonData itemData3 = new PushButtonData("NotImplemented005", "\u200B", assemFullName, "BIMnorm.Revit2023.Commands.");
            //itemData3.ToolTip = "";  // Tooltip
            //itemData3.Image = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_Default.png");
            //itemData3.LargeImage = RevitResourceLoader.LoadEmbeddedImage("BIMnorm.Revit2023.resources.icons.Img16x16_Default.png");

            // Ajoute les boutons PushButton et PulldownButton dans un groupe empilé
            IList<RibbonItem> stackedGroup1 = panel.AddStackedItems(itemData1, itemData2, itemData3);

            // Récupère le PushButton associé à itemData3 et le désactive
            PushButton item2 = stackedGroup1.OfType<PushButton>().FirstOrDefault(p => p.Name == itemData2.Name);
            item2.Enabled = false;

            // Récupère le PushButton associé à itemData3 et le désactive
            PushButton item3 = stackedGroup1.OfType<PushButton>().FirstOrDefault(p => p.Name == itemData3.Name);
            item3.Enabled = false;

        }

    }

}

/// Types de boutons :
/// - Single Button
/// - 
/// - Pulldown-name
/// - Stacked items
/// - split buttons
/// - Radio buttons
/// - slideout panel
/// https://www.youtube.com/watch?v=Rixm--qa7pg



//string thisAssemblyPath = Assembly.GetExecutingAssembly().Location;
//PushButtonData buttonData = new PushButtonData("cmdHelloWorld", "Hello World", thisAssemblyPath, "BIMnorm.Revit2023.RunDynamoCommand");
//    PushButton pushButton = ribbonPanel.AddItem(buttonData) as PushButton;